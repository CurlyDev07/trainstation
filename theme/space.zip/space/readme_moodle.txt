 Addons:
Siema - Lightweight and simple carousel in pure JavaScript
https://pawelgrzybek.github.io/siema/

Automatically add a progress bar to your site. #hubspot-open-source
https://github.hubspot.com/pace/docs/welcome/

A javascript scrollbar plugin which hides native scrollbars, provides custom styleable overlay scrollbars and keeps the native functionality and feeling.
https://github.com/KingSora/OverlayScrollbars

FontAwesome
https://fontawesome.com

GoogleFonts
https://fonts.google.com

Bootstrap Cookie Alert by Wruczek
https://github.com/Wruczek/Bootstrap-Cookie-Alert

Bootstrap 4 Multi level dropdown navigation
https://github.com/bootstrapthemesco/bootstrap-4-multi-dropdown-navbar